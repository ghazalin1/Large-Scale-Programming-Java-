import javax.swing.*;
import java.awt.EventQueue;
import javax.swing.event.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
//All the packages imported above

public class MyCalculator {
    // Added private JTextFields,JFrame, answerField,boolean ,char,  double ;
	//private JButton one,two,three,four,five,six,seven,eight,nine,add,sub,multiply,divide,equals,clear.  ALL INCLUDED
	//I added JFrame to make a (Window) frame
	// GUI items
	private JFrame frame; 
	private JTextField resultField;
	public String Canswer= null,s1="",s2=""; //Two Strings created to initialize
	public double answer=0.0;  
	public char operation;
	public boolean ss=true,dec=false;
	private JTextField num1;
	private JTextField num2;
	
	
	// The Calculator example given below and launching one. 
	//  Using a try catch method in GUI. Reads data from text fields.
	public static void main(String[] args) {
		 {		try {
					String example=".1"; //Convert strings into integer number
					System.out.println(Double.parseDouble(example)+0.1);  //  result sends to the text result GUI item
					MyCalculator window = new MyCalculator();
					window.frame.setVisible(true);
				} catch (Exception e) {
				}
			}
		}

	// Creating the calculator application methods below.
	// constructor
	public MyCalculator() {
		initialize();
	}
// Initialize the contents of the frame.
// set user interface and size of the window
	private void initialize() {
		
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(470, 225, 400, 285);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		// Initializing GUI items 1,2,3,4 etc... Labels
        // Initializing JButtons
		JButton button1 = new JButton("1");
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ss){s1+="1";resultField.setText(s1);}
				else {s2+="1";resultField.setText(s2);}
			}
		});
		button1.setBounds(50, 140, 75, 25);
		frame.getContentPane().add(button1);
		
		JButton button2 = new JButton("2");
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ss){s1+="2";resultField.setText(s1);}
				else {s2+="2";resultField.setText(s2);}
			}
		});
		button2.setBounds(125, 140, 75, 25);
		frame.getContentPane().add(button2);
		
		JButton button3 = new JButton("3");
		button3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ss){s1+="3";resultField.setText(s1);}
				else {s2+="3";resultField.setText(s2);}
			}
		});
		button3.setBounds(200, 140, 75, 25);
		frame.getContentPane().add(button3);
		
		JButton button4 = new JButton("4");
		button4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ss){s1+="4";resultField.setText(s1);}
				else {s2+="4";resultField.setText(s2);}
			}
		});
		button4.setBounds(50, 165, 75, 25);
		frame.getContentPane().add(button4);
		
		JButton button5 = new JButton("5");
		button5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ss){s1+="5";resultField.setText(s1);}
				else {s2+="5";resultField.setText(s2);}
			}
		});
		button5.setBounds(125, 165, 75, 25);
		frame.getContentPane().add(button5);
		
		JButton button6 = new JButton("6");
		button6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ss){s1+="6";resultField.setText(s1);}
				else {s2+="6";resultField.setText(s2);}
			}
		});
		button6.setBounds(200, 165, 75, 25);
		frame.getContentPane().add(button6);
		
		JButton button7 = new JButton("7");
		button7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ss){s1+="7";resultField.setText(s1);}
				else {s2+="7";resultField.setText(s2);}
			}
		});
		button7.setBounds(50, 190, 75, 25);
		frame.getContentPane().add(button7);
		
		JButton button8 = new JButton("8");
		button8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ss){s1+="8";resultField.setText(s1);}
				else {s2+="8";resultField.setText(s2);}
			}
		});
		button8.setBounds(125, 190, 75, 25);
		frame.getContentPane().add(button8);
		
		JButton button9 = new JButton("9");
		button9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ss){s1+="9";resultField.setText(s1);}
				else {s2+="9";resultField.setText(s2);}
			}
		});
		button9.setBounds(200, 190, 75, 25);
		frame.getContentPane().add(button9);
		
		JButton button0 = new JButton("0");
		button0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ss){s1+="0";resultField.setText(s1);
				//if(stemp2=="")num1.setText("num1 : "+stemp1);
				}
				else {s2+="0";resultField.setText(s2);
				//if(stemp1!="")num2.setText("num2 : "+stemp2);
				}
			}
		});
		button0.setBounds(125, 215, 75, 25);
		frame.getContentPane().add(button0);
		
		//JOptionPane.showMessageDialog to Calculate, Clear, Add , Subtract, Divide and Multiply;
		
		JButton buttonAdd = new JButton("+");
		buttonAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ss==true && s1!=""){ss=false;resultField.setText("");
				//if(stemp2=="")num1.setText("num1 : "+stemp1);
				dec=false;
				}
				if(ss==false)operation='+';
				//if(stemp1!="")num2.setText("num2 : "+stemp2);
			}
		});
		buttonAdd.setBounds(275, 140, 75, 25);
		frame.getContentPane().add(buttonAdd);
		
		JButton buttonSub = new JButton("-");
		buttonSub.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ss==true && s1!=""){ss=false;resultField.setText("");
				dec=false;}
				if(ss==false)operation='-';
			
			}
		});
		buttonSub.setBounds(275, 165, 75, 25);
		frame.getContentPane().add(buttonSub);
		
		JButton buttonMul = new JButton("*");
		buttonMul.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(ss==true && s1!=""){ss=false;resultField.setText("");
				dec=false;
				}
				if(ss==false)operation='*';
			}
		});
		buttonMul.setBounds(275, 190, 75, 25);
		frame.getContentPane().add(buttonMul);
		
		JButton buttonDiv = new JButton("/");
		buttonDiv.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(ss==true && s1!=""){ss=false;resultField.setText("");
				dec=false;}
				if(ss==false)operation='/';
			}
		});
		buttonDiv.setBounds(275, 215, 75, 25);
		frame.getContentPane().add(buttonDiv);
		
		// helper method to make calculations 
		//Creating Equal sign
		// resultField created for answer operations
    	JButton buttonEq = new JButton("Calculate");
		buttonEq.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ss==false && s1!="" && s2!=""){
					ss=true;dec=false;
					if(operation=='+')
						resultField.setText(Double.toString
							(Double.parseDouble(s1)+Double.parseDouble(s2)));
					else if(operation=='-')
						resultField.setText(Double.toString
								(Double.parseDouble(s1)-Double.parseDouble(s2)));
					else if(operation=='*')
						resultField.setText(Double.toString
								(Double.parseDouble(s1)*Double.parseDouble(s2)));
					else if(operation=='/'){
						if(Double.parseDouble(s2)==0.0){
							JOptionPane.showMessageDialog(null, "Can't divide by zero, can you?");
						}else{
						resultField.setText(Double.toString
								(Double.parseDouble(s1)/Double.parseDouble(s2)));
						}
						}s1="";
						s2="";
						operation='a';
				}
			}
		});//setting fonts bounds and columns.
		buttonEq.setBounds(50,215 , 75, 25);
		frame.getContentPane().add(buttonEq);
		buttonEq.setFont(new Font("Tahoma", Font.BOLD, 7));
		//setting fonts bounds and columns.
	   JButton buttonX = new JButton("Clear");
		buttonX.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ss){
					if(s1!=""){
						s1=s1.substring(0,s1.length()-1);
						if(s1.lastIndexOf(".")!=-1)dec=true;else dec=false;
					}
					if(s1.length()<=0){s1="";dec=false;}
					resultField.setText(s1);
					if(s1=="" && s2==""){resultField.setText("0.0");}
					//if(s2=="")num1.setText("num1 : "+s1);
				}
				else{
					if(s1.length()<=0)ss=true;
					else{
					if(s2!=""){
						s2=s2.substring(0,s2.length()-1);
						if(s2.lastIndexOf(".")!=-1)dec=true;else dec=false;
					}
					if(s2.length()<=0){s2="";dec=false;}
					resultField.setText(s2);
					}
				}
			}
		});
		buttonX.setBounds(200, 215, 75, 25);
		frame.getContentPane().add(buttonX);
		buttonX.setFont(new Font("Accanthis ADF Std", Font.BOLD, 7));
		
		//setting fonts bounds and columns.
		resultField = new JTextField();
		resultField.setFont(new Font("Accanthis ADF Std", Font.BOLD, 15));
		resultField.setEditable(false);
		resultField.setBounds(50, 25, 295, 95);
		frame.getContentPane().add(resultField);
		resultField.setColumns(10);
		
		}
}